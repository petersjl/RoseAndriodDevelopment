package com.zehren.foodrater

data class Food (var name: String, var resource: Int, var rating: Int = 0)