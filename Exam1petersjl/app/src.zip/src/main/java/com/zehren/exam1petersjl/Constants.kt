package com.zehren.exam1petersjl

object Constants {
    const val TAG = "fontnow"
    const val LOREM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam congue vel " +
            "elit sit amet placerat. " +
            "Maecenas eget nisi mi. Duis placerat vulputate accumsan. Aliquam ac ultrices urna. Nunc" +
            " dignissim blandit dolor laoreet pulvinar. Ut ornare quam massa, luctus blandit justo " +
            "ultrices maximus. Nulla quis massa gravida, elementum arcu vitae, consequat odio. Morbi" +
            " ac nisi sit amet sem mattis semper nec a quam. Proin pretium massa at feugiat congue." +
            "\n\n Donec eu ipsum cursus, volutpat odio at, molestie felis. Integer id justo vel mi " +
            "euismod lacinia. Curabitur egestas sapien non luctus fermentum. Nulla eu suscipit leo," +
            " congue congue tortor. Quisque feugiat, sapien ut fermentum vehicula, dolor lacus " +
            "viverra elit, eget vehicula diam dolor sed neque. Nunc lacus est, rutrum ac justo ut, " +
            "laoreet eleifend metus. Ut condimentum eleifend lorem, sed interdum purus placerat " +
            "euismod. Curabitur lobortis nisl nec quam interdum porta. Donec non varius augue. " +
            "Duis sed lobortis elit. Cras odio risus, laoreet id posuere a, efficitur in risus. " +
            "Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus." +
            " Nullam eget felis sem. Donec lacinia, quam interdum finibus consequat, arcu mi tempor " +
            "urna, accumsan elementum nisi risus non augue. Donec volutpat turpis pulvinar ligula " +
            "pellentesque, in scelerisque nibh dapibus. Integer mattis lobortis ex quis volutpat."
}